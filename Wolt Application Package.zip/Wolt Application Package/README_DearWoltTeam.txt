Dear Wolt Team

I wanted to add to the files attached this as a thank you note. I noted it on the assignment as well, but this has been a great learning experience for me. 
My background is academic research and I had always used the same three or four tools for it as it is common in the field. And this assignment has been motivating enough for me to go out there and challenge myself into transferring those skills into a new language as is Python. 
I had never developed this much work using it and I even surprised myself I think with how well it went. I have dedicated time to learn and understand it so I could provide a more consistent report than just changing one scatterplot function for another, and the learning process has been challenging but very satisfying. 

I am excited to keep learning and improving at my analysis and reporting skills, and as someone who has lived the Wolt experience first hand as a rider, I am sure that there is so much more potential data, links and trends to discover asess and make use of. 
I am looking forward to your feedback on the assignment and hopefull that I can achieve my full potential by learning from the skilled data professionals at Wolt.

Thanks again for your attention and your challenge.

Best regards,

Ignacio Valero